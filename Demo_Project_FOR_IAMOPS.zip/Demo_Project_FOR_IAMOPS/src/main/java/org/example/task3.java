package org.example;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class task3 {

    public static void main(String args[]){


        //Set up the path for firefox driver
        System.setProperty("webdriver.gecok.driver","D://seliniumJar&DRIVERSS/firefoxdriver/geckodriver.exe");
        //Initializing the firefox driver
        WebDriver driver= new FirefoxDriver();

        //navigate to the airIndia Sit
        driver.get("https://www.airindia.com/");
        driver.manage().window().maximize();


        //search for a flight from Mumbai to Toronto

        WebElement fromField= driver.findElement(By.xpath("//input[@id='From']"));
        fromField.sendKeys("Mumbai");

        //enter toronto in to filed
        WebElement toField=driver.findElement(By.xpath("//input[@id='To']"));
        toField.sendKeys("Toronto");

        //select 5 Adults and 2 Children
        WebElement adultDropeDown=driver.findElement(By.xpath("//button[normalize-space()='Adult 1']"));
        adultDropeDown.click();
        WebElement childrenDropDown=driver.findElement(By.xpath("//button[normalize-space()='Adult 1']"));
        childrenDropDown.click();


        //Depart date is 25 December and Return Date is 10  January.
        WebElement departDate=driver.findElement(By.xpath("//button[normalize-space()='25 Dec 2023']"));
        departDate.sendKeys("25Dec2023");

        WebElement returnDate=driver.findElement(By.xpath("//button[normalize-space()='10 Jan 2024']"));
        returnDate.sendKeys("10Jan2024");

        driver.quit();

    }





}
