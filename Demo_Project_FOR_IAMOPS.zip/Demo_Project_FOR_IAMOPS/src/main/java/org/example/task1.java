package org.example;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;


// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class task1 {

    public static void main(String args[]){

        //Set up the path for firefox driver
        System.setProperty("webdriver.gecok.driver","D://seliniumJar&DRIVERSS/firefoxdriver/geckodriver.exe");
        //Initializing the firefox driver
        WebDriver driver= new FirefoxDriver();

        //Test case 1: Positive LogIn test
        positiveLoginTest(driver);

        //Test case 2: Negative username test
        negativeUsernameTest(driver);

        //Test case 3: Negative password test

       negativePasswordTest(driver);
        //quit the driver
        driver.quit();


    }

    private static void positiveLoginTest(WebDriver driver){
        //navigating to the user page
        driver.get("https://practicetestautomation.com/practice-test-login/");
        login(driver, "student","Password123 ");

        Assert.assertTrue(driver.getCurrentUrl().contains("https://practicetestautomation.com/practice-test-login/"));
        Assert.assertTrue(driver.getPageSource().contains("Congratulations")||driver.getPageSource().contains("successfully logged in"));
        Assert.assertTrue(driver.findElement(By.xpath("//a[normalize-space()='Log out']")).isDisplayed());

    }

    private static void negativeUsernameTest(WebDriver driver){
        driver.get("https://practicetestautomation.com/practice-test-login/");

        login(driver,"incorrectUser","Password123");

        WebElement errorMessage=driver.findElement(By.id("error"));
        Assert.assertTrue(errorMessage.isDisplayed());
        Assert.assertEquals(errorMessage.getText(),"Your username is invalid!");
    }


    private static void negativePasswordTest(WebDriver driver){
        driver.get("https://practicetestautomation.com/practice-test-login/");
        login(driver,"student","incorrectPassword ");


        WebElement errorMessage=driver.findElement(By.id("error"));
        Assert.assertTrue(errorMessage.isDisplayed());
        Assert.assertEquals(errorMessage.getText(),"Your password is invalid!");

    }

    private static void login(WebDriver driver, String username, String password) {

        WebElement userNameField=driver.findElement(By.id("username"));
        WebElement passwordField= driver.findElement(By.id("password"));
        WebElement submiteButton= driver.findElement(By.id("submit"));

     userNameField.sendKeys("student");
     passwordField.sendKeys("Password123");
     submiteButton.click();

    }

}